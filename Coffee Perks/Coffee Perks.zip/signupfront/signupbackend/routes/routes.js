const express = require('express')
const router = express.Router()
const signUpTemplateCopy = require('../models/SignUpModels')
const bcrypt = require('bcrypt') // imports bcrypt used to encrypt password


router.post('/signup', async (request, response) =>{    // post statement to submit user info to the DB
    
    //import method here to check if user is already registered and boostrap alert if so
    
    
    const saltPassword = await bcrypt.genSalt(10)
    const securePassword = await bcrypt.hash(request.body.password, saltPassword) //Salts and hashes password entered by user
    
    const signedUpUser = new signUpTemplateCopy({
        fullName:request.body.fullName,
        username:request.body.username,
        email:request.body.email,
        password:securePassword //encrypted password will replace user entered password in MongoDB
    })
    
   
    signedUpUser.save()
    .then(data =>{
        response.json(data)
    })
    .catch(error =>{
        response.json(error);
        console.log('Error is ', error)
      
        
    })

})

module.exports = router