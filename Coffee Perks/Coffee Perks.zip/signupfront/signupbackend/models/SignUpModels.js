var validator = require('validator');
const mongoose = require('mongoose')

const signUpTemplate = new mongoose.Schema({
    fullName: {
        type: String,
        required: [true, "Full Name is required."] //Alerts User that Full Name is required

    },
    username: {
        type: String,
        required: [true, "Username is required."] //Alerts User that UserName is required
    },
    email: {
        type: String,
        required: [true, "Email is required."], //Alerts Username that Email is required
        unique: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('Invalid Email'); // Throws error "Invalid Email" when invalid

            }
        }
    },
    password: {
        type: String,
        required: [true, "Password is required."], //Alerts Username that Password is required
        validate(value) {
            if (!validator.isStrongPassword(value)) {
                throw new Error('Password must be at least 8 characters, contain at least: 1 Lowercase letter, 1 Uppercase letter, 1 number, and 1 symbol')
            }   // Throws error when input does not meet password requirements above. 
        }
    },
    date: {
        type: Date,
        default: Date.now
    }
})

// Checks if email entered by user is already present in DB
signUpTemplate.path('email').validate(async (email) => {
    const emailCount = await mongoose.models.mytable.countDocuments({ email })
    return !emailCount
  }, 'Email already exists')

module.exports = mongoose.model('mytable', signUpTemplate)