import React from 'react'
//import banner from './banner.png'
import coffeePerks from './images/coffeePerks.png'
const Banner = () => {
    return (
        <div className='bannerIMG'>
            <img src={coffeePerks} alt='banner' />
        </div>
    )
}

export default Banner
