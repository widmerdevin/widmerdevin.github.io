import React from 'react'
import freeCoffee from './images/freeCoffee.png'
import peppermintMocha from './images/peppermintMocha.png'
import Muffin from './images/Muffin.png'
import Frappe from './images/Frappe.png'
import Card from 'react-bootstrap/Card'

const Offers = () => {
    return (
        
        <div className ='offerBox'>
        <Card>
            <Card.Header>Check Out Our Current Offers Below!</Card.Header>
        <Card.Body>
        <div class="d-flex flex-row">
        <div class="p-2">
            <div class="freeCoffee">
                    <img src={freeCoffee} alt='freeCoffee'/>
            </div></div>
            <div class="p-2">
            <div class="peppermintMocha">
                    <img src={peppermintMocha} alt='peppermintMocha'/>
            </div>
            </div>
            </div>
            <div class="d-flex flex-row">
        <div class="p-2">
            <div class="Muffin">
                    <img src={Muffin} alt='Muffin'/>
            </div></div>
            <div class="p-2">
            <div class="Frappe">
                    <img src={Frappe} alt='Frappe'/>
            </div>
            </div>
            </div>
            </Card.Body>
        </Card>
        </div>
        
    )
}

export default Offers
