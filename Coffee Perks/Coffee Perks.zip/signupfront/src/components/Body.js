import React from 'react'
import './index.css'
import Card from 'react-bootstrap/Card'


const Body = () => {
    return (
        <div className ='homeBody' >
                        <Card>
                            <Card.Header>Frequently Asked Questions</Card.Header>
                        <Card.Body>
                        <Card.Title><h4>What is Coffee Perks?</h4></Card.Title>
                       <Card.Text> <p>Coffee Perks is a loyalty program that provides coffee enthusiasts with access to
                            discounts and promotions available for use at their local coffee shop. This program is
                            perfect for all of those coffee fanatics who can't get their day started without a fresh
                            and strongly brewed cup of signature coffee. You can sign up for the Coffee Perks loyalty
                            program by using the short form below. After you submit the form, you will receive a welcome 
                            email which contains all of the information you will need to get started as well as 
                            an exclusive introductory offer for new members.
                         </p>
                        </Card.Text>
                        <Card.Title><h4>How much does a Coffee Perks membership cost?</h4></Card.Title>
                        <Card.Text><p> A membership for the Coffee Perks loyalty program is 100%, absolutely free! Yeah, you read
                            that right! Our members enjoy free cups of coffee, holiday promotions, and delightful 
                            discounts absolutely free of charge. All you have to do to get start is Sign Up with your 
                            name, email, username, and password. Once you sign up you will receive a confirmation email 
                            shortly and your will be eligible for all of our current and future promotions.
                        </p>
                        </Card.Text>
                        </Card.Body>
                        </Card>
                    </div>
    )

 
}


export default Body



