import React, { Component } from 'react';
import "bootstrap/dist/css/bootstrap.min.css"
import axios from 'axios'




class App extends Component {
    constructor(){
        super()
        this.state = {
            fullName:'',  
            username:'',
            email:'',
            password:''
        }
        this.changeFullName = this.changeFullName.bind(this)
        this.changeEmail = this.changeEmail.bind(this)
        this.changeUsername = this.changeUsername.bind(this)
        this.changePassword = this.changePassword.bind(this)
        this.onSubmit = this.onSubmit.bind(this)
    }

    changeFullName(event){
        this.setState({
            fullName:event.target.value
        })
    }
    changeUsername(event){
        this.setState({
            username:event.target.value
        })
    }
    changeEmail(event){
        this.setState({
            email:event.target.value
        })
    }
    changePassword(event){
        this.setState({
            password:event.target.value
        })
    }

    onSubmit(event){
        event.preventDefault() /*prevents form from refreshing the page after submit*/

        const registered = { /* collects the values entered by the user and are stored in registered */
            fullName: this.state.fullName, 
            username: this.state.username, 
            email: this.state.email, 
            password: this.state.password
        }

        axios.post('http://localhost:4000/app/signup', registered) /* Sends post request for data stored in registered to backend */
        .then(response => console.log(response.data))
    
        this.setState({
            fullName:'',
            username:'',
            email:'',
            password:''
        })
    }

    render(){
        return (  

            
                    <div className='form-div'>  {/* This form is what customers are entering their info into on the signup page*/}
                        <h2>Sign Up Here!</h2>
                        <form onSubmit={this.onSubmit}>     {/* on submit event handler*/}                                 
                            <input type = 'text'
                            placeholder='Full Name'
                            onChange={this.changeFullName}
                            value={this.state.fullName}
                            className='from-control form-group'
                            />

                            <input type='text'
                            placeholder='Username'
                            onChange={this.changeUsername}
                            value={this.state.username}
                            className='from-control form-group'
                            />

                            <input type='text'
                            placeholder='E-mail'
                            onChange={this.changeEmail}
                            value={this.state.email}
                            className='from-control form-group'
                            />

                            <input type='password'
                            placeholder='Password'
                            onChange={this.changePassword}
                            value={this.state.password}
                            className='from-control form-group'
                            />

                            <input type='submit' className='btn btn-danger btn-block' value='Submit' /> {/* Submit Button*/}


                        </form>
                    </div>
                  
        );

    }
}

export default App;